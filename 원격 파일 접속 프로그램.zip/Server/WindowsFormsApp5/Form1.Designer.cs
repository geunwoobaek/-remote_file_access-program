﻿namespace WindowsFormsApp5
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.IP_TEXT = new System.Windows.Forms.TextBox();
            this.PORT_TEXT = new System.Windows.Forms.TextBox();
            this.PATH_TEXT = new System.Windows.Forms.TextBox();
            this.txt_all = new System.Windows.Forms.TextBox();
            this.server_button = new System.Windows.Forms.Button();
            this.path_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.FBD = new System.Windows.Forms.FolderBrowserDialog();
            this.history = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // IP_TEXT
            // 
            this.IP_TEXT.Location = new System.Drawing.Point(82, 41);
            this.IP_TEXT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.IP_TEXT.Name = "IP_TEXT";
            this.IP_TEXT.Size = new System.Drawing.Size(585, 25);
            this.IP_TEXT.TabIndex = 0;
            this.IP_TEXT.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // PORT_TEXT
            // 
            this.PORT_TEXT.Location = new System.Drawing.Point(81, 104);
            this.PORT_TEXT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PORT_TEXT.Name = "PORT_TEXT";
            this.PORT_TEXT.Size = new System.Drawing.Size(585, 25);
            this.PORT_TEXT.TabIndex = 1;
            // 
            // PATH_TEXT
            // 
            this.PATH_TEXT.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.PATH_TEXT.Cursor = System.Windows.Forms.Cursors.Default;
            this.PATH_TEXT.Enabled = false;
            this.PATH_TEXT.ForeColor = System.Drawing.SystemColors.WindowText;
            this.PATH_TEXT.Location = new System.Drawing.Point(82, 170);
            this.PATH_TEXT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PATH_TEXT.Name = "PATH_TEXT";
            this.PATH_TEXT.Size = new System.Drawing.Size(585, 25);
            this.PATH_TEXT.TabIndex = 2;
            this.PATH_TEXT.TextChanged += new System.EventHandler(this.PATH_TEXT_TextChanged);
            // 
            // txt_all
            // 
            this.txt_all.Location = new System.Drawing.Point(82, 222);
            this.txt_all.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_all.Multiline = true;
            this.txt_all.Name = "txt_all";
            this.txt_all.Size = new System.Drawing.Size(585, 245);
            this.txt_all.TabIndex = 3;
            // 
            // server_button
            // 
            this.server_button.Location = new System.Drawing.Point(702, 69);
            this.server_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.server_button.Name = "server_button";
            this.server_button.Size = new System.Drawing.Size(75, 41);
            this.server_button.TabIndex = 4;
            this.server_button.Text = "서버켜기";
            this.server_button.UseVisualStyleBackColor = true;
            this.server_button.Click += new System.EventHandler(this.server_button_Click);
            // 
            // path_button
            // 
            this.path_button.Location = new System.Drawing.Point(702, 137);
            this.path_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.path_button.Name = "path_button";
            this.path_button.Size = new System.Drawing.Size(75, 22);
            this.path_button.TabIndex = 5;
            this.path_button.Text = "경로선택";
            this.path_button.UseVisualStyleBackColor = true;
            this.path_button.Click += new System.EventHandler(this.path_button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "IP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "PORT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "PATH";
            // 
            // FBD
            // 
            this.FBD.HelpRequest += new System.EventHandler(this.folderBrowserDialog1_HelpRequest);
            // 
            // history
            // 
            this.history.Location = new System.Drawing.Point(82, 472);
            this.history.Multiline = true;
            this.history.Name = "history";
            this.history.Size = new System.Drawing.Size(585, 194);
            this.history.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(800, 678);
            this.Controls.Add(this.history);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.path_button);
            this.Controls.Add(this.server_button);
            this.Controls.Add(this.txt_all);
            this.Controls.Add(this.PATH_TEXT);
            this.Controls.Add(this.PORT_TEXT);
            this.Controls.Add(this.IP_TEXT);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = " server";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox IP_TEXT;
        private System.Windows.Forms.TextBox PORT_TEXT;
        private System.Windows.Forms.TextBox PATH_TEXT;
        private System.Windows.Forms.TextBox txt_all;
        private System.Windows.Forms.Button server_button;
        private System.Windows.Forms.Button path_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.FolderBrowserDialog FBD;
        private System.Windows.Forms.TextBox history;
    }
}

