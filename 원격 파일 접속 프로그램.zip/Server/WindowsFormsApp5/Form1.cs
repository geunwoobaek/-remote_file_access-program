﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using packet_libirary;
namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {     
    
    public Form1()
        {
            InitializeComponent();
        }
        
        public int now = 0;
        public NetworkStream m_Stream;
        public StreamReader m_Read;
        public StreamWriter m_Write;
        public int PORT;
        private delegate void AddTextDelegate(string strText);
     //   private Thread m_ThReader;
        public bool Collected = false;
        private TcpListener Server;
        TcpClient Client;
        private Thread m_thServer;
        private Thread Receive_thread;
        public bool m_bConnect = false;
        //pakcetNework       
        private byte[] sendBuffer = new byte[1024 * 4];
        private byte[] readBuffer = new byte[1024 * 4];
        private byte[] FIlesendBuffer = new byte[1024 * 4 * 3000];
        private byte[] FilereadBuffer = new byte[1024 * 4 * 3000];
        //sending class

        TreeNode root;
        TreeView trvDir = new TreeView();
        ListView lvwFiles= new ListView();
       
        int nread;
        public string Path;

        public void Send()
        {           
            m_Stream.Write(sendBuffer, 0, sendBuffer.Length);
            m_Stream.Flush();

            for (int i = 0; i < 1024 * 4; i++)
            {
                this.sendBuffer[i] = 0;
            }
        }

        public void SendFile()
        {
            m_Stream.Write(FIlesendBuffer, 0, FIlesendBuffer.Length);
            m_Stream.Flush();          
        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void path_button_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.RootFolder = Environment.SpecialFolder.Desktop;
            Environment.GetLogicalDrives();
            fbd.Description = "Select Folder";
            fbd.ShowNewFolderButton = false;

            if(fbd.ShowDialog()==DialogResult.OK)
            {   
                PATH_TEXT.Text = fbd.SelectedPath;
                txt_all.Text = fbd.SelectedPath;
                txt_all.AppendText(" 로 경로가 변경되었습니다.\n  ");
                txt_all.AppendText("\r\n");
     
            }
         
        }
        public void Message(string msg)
        {
            txt_all.AppendText(msg + "\r\n");
            txt_all.Focus();
            txt_all.ScrollToCaret();
        }
        public void Receive()
        {   
            AddTextDelegate AddText = new AddTextDelegate(txt_all.AppendText);
            Invoke(AddText, "Receive!" + "\r\n");
            while (Collected == true)
            {
              //  Thread.Sleep(1);
                if (m_Stream.CanRead)
                {   
                    m_Stream.Read(readBuffer, 0, 1024 * 4);
                        PMessage Pm = new PMessage();
                    Pm = (PMessage)Packet.Desserialize(this.readBuffer);
                    for (int i = 0; i < 1024 * 4; i++)
                    {
                        this.readBuffer[i] = 0;
                    }
                    if (Pm.command!=null)
                        Invoke(AddText, Pm.command);
                        Invoke(AddText, "\r\n ");

                    if (Pm.command == "서버연결끉기")
                    {
                        Invoke(AddText, Pm.command);
                        Collected = false;
                    }
                    else if (Pm.command == "demand BeforeSelect")
                    {
                        Invoke(AddText, Pm.command);
                        Invoke(AddText, "\r\n");
                        Invoke(AddText, Pm.SelectedNode);
                        Invoke(AddText, "\r\n");
                        BeforeSelect(Pm);

                        Packet.Serialize(Pm).CopyTo(this.sendBuffer, 0);
                        Send();
                    }
                    else if (Pm.command == "demand BeforeExpand")
                    {
                        Invoke(AddText, Pm.command);
                        Invoke(AddText, "\r\n");
                        Invoke(AddText, Pm.SelectedNode);
                        Invoke(AddText, "\r\n");
                        BeforeExpand(Pm);
                        Packet.Serialize(Pm).CopyTo(this.sendBuffer, 0);
                        Send();
                    }
                    else if (Pm.command == "demand Selectfolder")
                    {
                        Invoke(AddText, Pm.command);
                        Invoke(AddText, "\r\n");
                        Invoke(AddText, Pm.SelectedNode);
                        Invoke(AddText, "\r\n");
                        BeforeSelect(Pm);
                        Packet.Serialize(Pm).CopyTo(this.sendBuffer, 0);
                        Send();
                    }
                    else if (Pm.command == "demand imformation")
                    {
                        FileInfo fileinfo;
                        string path = Pm.PATH;
                        fileinfo = new FileInfo(Pm.PATH);
                        fileimformation finfo = new fileimformation();
                        finfo.CreationTime = fileinfo.CreationTime.ToString();
                        finfo.DirectoryName = fileinfo.DirectoryName;
                        finfo.Extenstion = fileinfo.Extension;
                        finfo.Len = fileinfo.Length.ToString();
                        finfo.LastWriteTime = fileinfo.LastWriteTime.ToString();
                        finfo.LastAccessTime = fileinfo.LastAccessTime.ToString();
                        Packet.Serialize(finfo).CopyTo(this.sendBuffer, 0);
                        Send();
                        //MessageBox.Show(msg);

                    }
                    else if (Pm.command == "demand Download")
                    {
                        FileInfo fileinfo;
                        FileStream filestream;
                        byte[] buf;
                        string path = Pm.PATH;
                        fileinfo = new FileInfo(Pm.PATH);
                        string fName = fileinfo.Name;
                        try
                        {
                            filestream = new FileStream(path, FileMode.Open, FileAccess.Read);
                            buf = new byte[filestream.Length];
                            filestream.Read(buf, 0, buf.Length);
                            filestream.Close();
                            PDownload pDown = new PDownload();
                            pDown.Filename = fName;
                            pDown.buf = buf;
                            pDown.filelength = buf.Length;
                            Packet.FileSerialize(pDown).CopyTo(this.FIlesendBuffer, 0);
                            SendFile();
                            Invoke(AddText, path + " " + "다운로드 시작..........." + "\r\n");
                        }
                        catch (Exception e)
                        {
                            MessageBox.Show("해당 파일은 없습니다.", "Error");
                        }
                    }
                  
                    
                  

                }
             
            }
        }
        public void Listen()
        {
            AddTextDelegate AddText = new AddTextDelegate(txt_all.AppendText);          
            var port = int.Parse(PORT_TEXT.Text);
            IPAddress localAddr = IPAddress.Parse(IP_TEXT.Text);
            try
            {
                Server = new TcpListener(localAddr, port);
                Server.Start();
                Collected = true;
               
            }
            catch (SocketException e)
            {
                txt_all.Text = "IP or PORT error";
                Server.Stop();
            }
            Invoke(AddText, "wait to Client!" + "\r\n");
            Client = Server.AcceptTcpClient();
            Invoke(AddText, "Connected to Client!" + "\r\n");
            m_Stream = Client.GetStream(); // 클라이언트 스트림 값 받아오기
            PMessage first = new PMessage();
            first.command = "첫번째 경로";
            first.message = PATH_TEXT.Text;
            Packet.Serialize(first).CopyTo(this.sendBuffer, 0);
            this.Send();
            m_Stream.Flush();
            Invoke(AddText, "경로전송!" + "\r\n");
            //첫번째 경로 trvDir에넣기
            root = trvDir.Nodes.Add(PATH_TEXT.Text);
            root.ImageIndex = 2;
            if (trvDir.SelectedNode == null)
            {
                trvDir.SelectedNode = root;
            }
            root.Nodes.Add("");
            m_Read = new StreamReader(m_Stream);
            m_Write = new StreamWriter(m_Stream);
            Receive_thread = new Thread(new ThreadStart(Receive)); // 값을 받기 위한 쓰레드
            Receive_thread.Start();

       
        }
        public void ServerStop()
        {
            if (!Collected)
                return;
            Server.Stop();
            //m_Read.Close();
           // m_Write.Close();

          //  m_Stream.Close();

      //      m_ThReader.Abort();
       //     m_thServer.Abort();

            txt_all.Text= "서비스 종료 \n";
        }
        public void Disconnect()
        {  
            if (!m_bConnect)
                return;
            m_bConnect = false;

            try
            {
                m_Read.Close();
                m_Write.Close();
            }
            catch { }
            m_Stream.Close();
            //    m_ThReader.Abort();
            this.Invoke(new MethodInvoker(delegate () {
                txt_all.AppendText(" 클라이언트 접속 끉어짐!\n\r ");
                txt_all.AppendText("\r\n");
            }));


        }
        public void StopMessage()
        {
      
            txt_all.AppendText("클라이언트 접속 대기중....\n\r   ");
            txt_all.AppendText("\r\n");
            server_button.Text = "서버멈춤";
            txt_all.AppendText("\r\n");
            server_button.ForeColor = Color.Red;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void PATH_TEXT_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            
            ServerStop();
            Disconnect();
            if ( Receive_thread!= null) 
                  Receive_thread.Abort();
        }
        private void server_button_Click(object sender, EventArgs e)
        {
            if (PATH_TEXT.Text == "")
            {
                 MessageBox.Show("경로를 입력해주세요.");
            }
           
            else
            {   
                if (server_button.Text == "서버켜기")
                {
                Thread ListenThread = new Thread(new ThreadStart(Listen));
                    ListenThread.Start();
                    StopMessage();
                }
                else
                {
                    ServerStop();
                    server_button.Text = "서버켜기";
                    server_button.ForeColor = Color.Black;
                }
            }
        }
        //there is function for sending client
        public void setPlus(TreeNode node)
        {
            string path;
            DirectoryInfo dir;
            DirectoryInfo[] di;

            try
            {
                AddTextDelegate AddText = new AddTextDelegate(history.AppendText);
                path = node.FullPath;
                dir = new DirectoryInfo(path);
                Invoke(AddText, "this is setplus dir:");

                Invoke(AddText, dir.ToString());
                Invoke(AddText, "\r\n");
                di = dir.GetDirectories();
                Invoke(AddText, "this is setplus di[] :");
                Invoke(AddText, di.ToString());
                Invoke(AddText, "\r\n");
                if (di.Length > 0)
                    node.Nodes.Add("");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void BeforeExpand(PMessage A)
        {
            string path;
            DirectoryInfo dir;
            DirectoryInfo[] di;
            TreeNode node;
            try
            {
                TreeNode root;
                root = trvDir.Nodes.Add(A.SelectedNode);
                root.ImageIndex = 2;
                trvDir.SelectedNode = root;
                root.SelectedImageIndex = root.ImageIndex;
                root.Nodes.Add("");
                AddTextDelegate AddText = new AddTextDelegate(history.AppendText);
                trvDir.SelectedNode.Nodes.Clear();
                path = trvDir.SelectedNode.FullPath;
                
                //
                Invoke(AddText, "this is BeforeExpand path :");
                Invoke(AddText, path);
                Invoke(AddText, "\r\n");
                dir = new DirectoryInfo(path);
                A.di = dir;
                //
                Invoke(AddText, "this is BeforeExpand dir:");
                Invoke(AddText, dir.ToString());
                Invoke(AddText, "\r\n");
                di = dir.GetDirectories();
                A.diarray = di;
                //
                Invoke(AddText, "this is BeforeExpand di[]:");
                foreach (DirectoryInfo dirs in di)
                {
                    Invoke(AddText, di.ToString());
                    Invoke(AddText, "\r\n");
                    node = trvDir.SelectedNode.Nodes.Add(dirs.Name);
                    setPlus(node);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        private void BeforeSelect(PMessage B) 
        {
            DirectoryInfo di;
            //   DirectoryInfo direc;
            DirectoryInfo[] diarray;
            ListViewItem item;
            FileInfo[] fiArray;

            try
            {
                TreeNode root;
                root = trvDir.Nodes.Add(B.SelectedNode);
                root.ImageIndex = 2;
                trvDir.SelectedNode = root;
                root.SelectedImageIndex = root.ImageIndex;
                root.Nodes.Add("");
                AddTextDelegate AddText = new AddTextDelegate(history.AppendText);
                di = new DirectoryInfo(trvDir.SelectedNode.FullPath);
                B.di = di;
                Invoke(AddText, "this is BeforeSelect di:");
                Invoke(AddText, di.ToString());
                Invoke(AddText, "\r\n");               
                // txtPath.Text = A.SelectedNode.FullPath.Substring(0, 2) + A.SelectedNode.FullPath.Substring(3);
                lvwFiles.Items.Clear();

                diarray = di.GetDirectories();
                B.diarray = diarray;
                Invoke(AddText, "this is BeforeSelect diarray[]:");

                foreach (DirectoryInfo tdis in diarray)
                {
                    Invoke(AddText, tdis.ToString());
                    Invoke(AddText, "\r\n");
                    item = lvwFiles.Items.Add(tdis.Name);
                    item.SubItems.Add("");
                    item.SubItems.Add(tdis.LastWriteTime.ToString());
                    item.ImageIndex = 0;
                    item.Tag = "D";
                }
                fiArray = di.GetFiles();
                B.fiArray = fiArray;
                Invoke(AddText, "this is BeforeSelect fiArray[]:");

                foreach (FileInfo fis in fiArray)
                {   //
                    Invoke(AddText, fis.ToString());
                    Invoke(AddText, "\r\n");
                    //
                    item = lvwFiles.Items.Add(fis.Name);
                    item.SubItems.Add(fis.Length.ToString());
                    item.SubItems.Add(fis.LastWriteTime.ToString());
                    item.ImageIndex = 1;
                    item.Tag = "F";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
           }
           }
            
        



    }




    }
        
        
    
