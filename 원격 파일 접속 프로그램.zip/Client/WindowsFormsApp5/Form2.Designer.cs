﻿namespace WindowsFormsApp5
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.IP_TEXT = new System.Windows.Forms.TextBox();
            this.PATH_TEXT = new System.Windows.Forms.TextBox();
            this.PORT_TEXT = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.trvDir = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btn_Connect = new System.Windows.Forms.Button();
            this.OpeningFolder = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.lvwFiles = new System.Windows.Forms.ListView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuImformation = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDownload = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDetail = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSimple = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSmall = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuLarge = new System.Windows.Forms.ToolStripMenuItem();
            this.FBD = new System.Windows.Forms.FolderBrowserDialog();
            this.history = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // IP_TEXT
            // 
            this.IP_TEXT.Location = new System.Drawing.Point(78, 59);
            this.IP_TEXT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.IP_TEXT.Name = "IP_TEXT";
            this.IP_TEXT.Size = new System.Drawing.Size(353, 25);
            this.IP_TEXT.TabIndex = 0;
            this.IP_TEXT.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // PATH_TEXT
            // 
            this.PATH_TEXT.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.PATH_TEXT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PATH_TEXT.Enabled = false;
            this.PATH_TEXT.Location = new System.Drawing.Point(143, 121);
            this.PATH_TEXT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PATH_TEXT.Name = "PATH_TEXT";
            this.PATH_TEXT.Size = new System.Drawing.Size(478, 25);
            this.PATH_TEXT.TabIndex = 1;
            this.PATH_TEXT.TextChanged += new System.EventHandler(this.PATH_TEXT_TextChanged);
            // 
            // PORT_TEXT
            // 
            this.PORT_TEXT.Location = new System.Drawing.Point(505, 59);
            this.PORT_TEXT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PORT_TEXT.Name = "PORT_TEXT";
            this.PORT_TEXT.Size = new System.Drawing.Size(116, 25);
            this.PORT_TEXT.TabIndex = 2;
            this.PORT_TEXT.TextChanged += new System.EventHandler(this.PORT_TEXT_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "IP:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(450, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "PORT:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "다운로드 경로:";
            // 
            // trvDir
            // 
            this.trvDir.ImageIndex = 0;
            this.trvDir.ImageList = this.imageList1;
            this.trvDir.Location = new System.Drawing.Point(11, 209);
            this.trvDir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.trvDir.Name = "trvDir";
            this.trvDir.SelectedImageIndex = 0;
            this.trvDir.Size = new System.Drawing.Size(180, 308);
            this.trvDir.TabIndex = 6;
            this.trvDir.BeforeLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.trvDir_BeforeLabelEdit);
            this.trvDir.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.trvDir_BeforeExpand);
            this.trvDir.BeforeSelect += new System.Windows.Forms.TreeViewCancelEventHandler(this.trvDir_BeforeSelect);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "avi.png");
            this.imageList1.Images.SetKeyName(1, "folder.png");
            this.imageList1.Images.SetKeyName(2, "image.png");
            this.imageList1.Images.SetKeyName(3, "music.png");
            this.imageList1.Images.SetKeyName(4, "temp.png");
            this.imageList1.Images.SetKeyName(5, "text.png");
            // 
            // btn_Connect
            // 
            this.btn_Connect.Location = new System.Drawing.Point(109, 168);
            this.btn_Connect.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Connect.Name = "btn_Connect";
            this.btn_Connect.Size = new System.Drawing.Size(75, 22);
            this.btn_Connect.TabIndex = 7;
            this.btn_Connect.Text = "서버연결";
            this.btn_Connect.UseVisualStyleBackColor = true;
            this.btn_Connect.Click += new System.EventHandler(this.button1_Click);
            // 
            // OpeningFolder
            // 
            this.OpeningFolder.Location = new System.Drawing.Point(473, 168);
            this.OpeningFolder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.OpeningFolder.Name = "OpeningFolder";
            this.OpeningFolder.Size = new System.Drawing.Size(75, 22);
            this.OpeningFolder.TabIndex = 8;
            this.OpeningFolder.Text = "폴더열기";
            this.OpeningFolder.UseVisualStyleBackColor = true;
            this.OpeningFolder.Click += new System.EventHandler(this.folderOpen_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(289, 168);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 22);
            this.button3.TabIndex = 9;
            this.button3.Text = "경로설정";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // lvwFiles
            // 
            this.lvwFiles.ContextMenuStrip = this.contextMenuStrip1;
            this.lvwFiles.LargeImageList = this.imageList1;
            this.lvwFiles.Location = new System.Drawing.Point(190, 209);
            this.lvwFiles.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lvwFiles.Name = "lvwFiles";
            this.lvwFiles.Size = new System.Drawing.Size(431, 308);
            this.lvwFiles.TabIndex = 10;
            this.lvwFiles.UseCompatibleStateImageBehavior = false;
            this.lvwFiles.DoubleClick += new System.EventHandler(this.lvwFiles_DoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuImformation,
            this.mnuDownload,
            this.mnuDetail,
            this.mnuSimple,
            this.mnuSmall,
            this.mnuLarge});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(154, 148);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            this.contextMenuStrip1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.mnuview_Click);
            // 
            // mnuImformation
            // 
            this.mnuImformation.Name = "mnuImformation";
            this.mnuImformation.Size = new System.Drawing.Size(153, 24);
            this.mnuImformation.Text = "상세정보";
            this.mnuImformation.Click += new System.EventHandler(this.mnuImformation_Click);
            // 
            // mnuDownload
            // 
            this.mnuDownload.Name = "mnuDownload";
            this.mnuDownload.Size = new System.Drawing.Size(153, 24);
            this.mnuDownload.Text = "다운로드";
            this.mnuDownload.Click += new System.EventHandler(this.mnuDownload_Click);
            // 
            // mnuDetail
            // 
            this.mnuDetail.Name = "mnuDetail";
            this.mnuDetail.Size = new System.Drawing.Size(153, 24);
            this.mnuDetail.Text = "자세히";
            this.mnuDetail.Click += new System.EventHandler(this.mnuDetail_Click);
            // 
            // mnuSimple
            // 
            this.mnuSimple.Name = "mnuSimple";
            this.mnuSimple.Size = new System.Drawing.Size(153, 24);
            this.mnuSimple.Text = "간단히";
            this.mnuSimple.Click += new System.EventHandler(this.mnuSimple_Click);
            // 
            // mnuSmall
            // 
            this.mnuSmall.Name = "mnuSmall";
            this.mnuSmall.Size = new System.Drawing.Size(153, 24);
            this.mnuSmall.Text = "작은아이콘";
            this.mnuSmall.Click += new System.EventHandler(this.mnuSmall_Click);
            // 
            // mnuLarge
            // 
            this.mnuLarge.Name = "mnuLarge";
            this.mnuLarge.Size = new System.Drawing.Size(153, 24);
            this.mnuLarge.Text = "큰아이콘";
            this.mnuLarge.Click += new System.EventHandler(this.mnuLarge_Click);
            // 
            // history
            // 
            this.history.Location = new System.Drawing.Point(12, 522);
            this.history.Multiline = true;
            this.history.Name = "history";
            this.history.Size = new System.Drawing.Size(609, 129);
            this.history.TabIndex = 11;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 651);
            this.Controls.Add(this.history);
            this.Controls.Add(this.lvwFiles);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.OpeningFolder);
            this.Controls.Add(this.btn_Connect);
            this.Controls.Add(this.trvDir);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PORT_TEXT);
            this.Controls.Add(this.PATH_TEXT);
            this.Controls.Add(this.IP_TEXT);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox IP_TEXT;
        private System.Windows.Forms.TextBox PATH_TEXT;
        private System.Windows.Forms.TextBox PORT_TEXT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TreeView trvDir;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btn_Connect;
        private System.Windows.Forms.Button OpeningFolder;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ListView lvwFiles;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuImformation;
        private System.Windows.Forms.ToolStripMenuItem mnuDownload;
        private System.Windows.Forms.ToolStripMenuItem mnuDetail;
        private System.Windows.Forms.ToolStripMenuItem mnuSimple;
        private System.Windows.Forms.ToolStripMenuItem mnuSmall;
        private System.Windows.Forms.ToolStripMenuItem mnuLarge;
        private System.Windows.Forms.FolderBrowserDialog FBD;
        private System.Windows.Forms.TextBox history;
    }
}