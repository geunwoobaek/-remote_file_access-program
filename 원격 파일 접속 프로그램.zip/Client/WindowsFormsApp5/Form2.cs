﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;//
using packet_libirary;
using System.Diagnostics;
namespace WindowsFormsApp5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        // Form3 Imformation;
        TcpClient client = null;
        public bool m_bConnect = false;
        //pakcetNework
        private NetworkStream stream;
        private byte[] sendBuffer = new byte[1024 * 4];
        private byte[] readBuffer = new byte[1024 * 4];
        private byte[] FIlesendBuffer = new byte[1024 * 4*3000];
        private byte[] FilereadBuffer = new byte[1024 * 4*3000];
        StreamReader Reader;
        StreamWriter Writer;
        private delegate void AddTextDelegate(string strText);
        public packet_libirary.PMessage message_Class;
        public PDownload download_Class;
        public fileimformation info_Class;
        private Thread ReceivedThread;
        //recieve class

        FileInfo[] fiArray;
        int nread;
        int a = 0;

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void PATH_TEXT_TextChanged(object sender, EventArgs e)
        {

        }
        public bool Send()
        {
            stream.Write(sendBuffer, 0, sendBuffer.Length);
            stream.Flush();

            for (int i = 0; i < 1024 * 4; i++)
            {
                this.sendBuffer[i] = 0;
            }
            return true;
        }
        public void Receive()
        {
            AddTextDelegate AddText = new AddTextDelegate(history.AppendText);
            Invoke(AddText, "Recieve() \r\n");
            //  while (m_bConnect == true)
            //   {
            if (stream.CanRead)
            {
                nread = 0;
                nread = this.stream.Read(readBuffer, 0, 1024 * 4);
                stream.Flush();
                //  Packet packet = (Packet)Packet.Desserialize(this.readBuffer);
                this.message_Class = (PMessage)Packet.Desserialize(this.readBuffer);
                if (message_Class.command == "첫번째 경로")
                {
                    this.Invoke(new MethodInvoker(delegate ()
                      {
                          TreeNode root;
                          root = trvDir.Nodes.Add(message_Class.message);
                          root.ImageIndex = 2;
                          if (trvDir.SelectedNode == null)
                              trvDir.SelectedNode = root;
                          root.SelectedImageIndex = root.ImageIndex;
                          root.Nodes.Add("");

                      }));
                    Invoke(AddText, "first() \r\n");
                }
            }
        }
        public void infoReceive()
        {
            AddTextDelegate AddText = new AddTextDelegate(history.AppendText);
            Invoke(AddText, "info_Recieve() \r\n");     
            if (stream.CanRead)
            {
                nread = 0;
                nread = this.stream.Read(readBuffer, 0, 1024*4);
                stream.Flush();              
                this.info_Class= (fileimformation)Packet.Desserialize(this.readBuffer); 
            }
        }
        public void fileReceive()
        {
            AddTextDelegate AddText = new AddTextDelegate(history.AppendText);
            Invoke(AddText, "fileRecieve() \r\n");
            if (stream.CanRead)
            {
                nread = 0;
                nread = this.stream.Read(FilereadBuffer, 0, 1024 * 4 * 3000);
                stream.Flush();
                this.download_Class = (PDownload)Packet.FileDesserialize(this.FilereadBuffer);
            }
        }
        public bool Connect()
        {
            client = new TcpClient();
            var port = int.Parse(PORT_TEXT.Text);
            IPAddress localAddr = IPAddress.Parse(IP_TEXT.Text);

            try
            {
                client.Connect(localAddr, port);
                
            }
            catch (SocketException E)
            {
                m_bConnect = false;
                MessageBox.Show("해당서버가 없습니다.");
                return true;
            }
            m_bConnect = true;
            return false;
        }

        public void Disconnect()
        {
            if (!m_bConnect)
                return;
            m_bConnect = false;
            //  Packet.Serialize(Init).CopyTo(sendBuffer, 0);
            //m_Read.Close();
            //m_Write.Close();
            PMessage Me = new PMessage();
            Me.Type = (int)PacketType.초기화;
            Me.command = "서버연결끉기";
            Me.PATH = "nono";
            stream.Flush();
            Packet.Serialize(Me).CopyTo(sendBuffer, 0);
            Send();
            stream.Close();
            ReceivedThread.Abort();
            trvDir.SelectedNode = null;
            trvDir.Refresh();
            trvDir.Nodes.Clear();
            lvwFiles.Clear();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (PATH_TEXT.Text == "")
                MessageBox.Show("경로를 입력해주세요", "Error");
            else
            {
              if (btn_Connect.Text == "서버연결")
                {

                    if(Connect())
                        return;
                    stream = client.GetStream();
                    ReceivedThread = new Thread(new ThreadStart(Receive));
                    ReceivedThread.Start();

                    if (m_bConnect == true)
                    {
                        btn_Connect.Text = "연결끊기";
                        btn_Connect.ForeColor = Color.Red;
                    }
                    else
                    {
                        Disconnect();
                        btn_Connect.Text = "서버연결";
                        btn_Connect.ForeColor = Color.Black;
                    }
                }
                else if (btn_Connect.Text == "연결끊기")
                {

                    Disconnect();
                    btn_Connect.Text = "서버연결";
                    btn_Connect.ForeColor = Color.Black;

                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.RootFolder = Environment.SpecialFolder.Desktop;
            fbd.Description = "Select Folder";
            fbd.ShowNewFolderButton = false;

            if (fbd.ShowDialog() == DialogResult.OK)
            {
                PATH_TEXT.Text = fbd.SelectedPath;

            }

        }
        public void OpenFiles()
        {
            PMessage Me = new PMessage();
            Me.command = "inside folder";
            Packet.Serialize(Me).CopyTo(sendBuffer, 0);
            Send();
            ListView.SelectedListViewItemCollection siList;
            siList = lvwFiles.SelectedItems;
            foreach (ListViewItem item in siList)
            {
                OpenItem(item);
            }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void mnuview_Click(object sender, MouseEventArgs e)
        {
            /*
            ContextMenu item = (ToolStripMenuItem)sender;

            mnuImformation.Checked = false;
            mnuSimple.Checked = false;
            mnuSmall.Checked = false;
            mnuLarge.Checked = false;

            switch (item.Text)
            {
                case "상세정보":
                    if (lvwFiles.SelectedItems[0].Tag == "D")
                        MessageBox.Show("디렉토리는 불가능합니다.", "ERROR");
                    else
                    {
                        Form3 Imformation = new Form3();
                        string msg = trvDir.SelectedNode.FullPath + '\\' + lvwFiles.SelectedItems[0].Text;
                        Imformation.Show();
                    }
                        break;
                case "자세히":
                    mnuDetail.Checked = true;
                    mnuSimple.Checked = false;
                    lvwFiles.View = View.Details;
                    break;
                case "간단히":
                    mnuSimple.Checked = true;
                    mnuDetail.Checked = false;
                    lvwFiles.View = View.List;
                    break;
                case "작은 아이콘":
                    mnuSmall.Checked = true;
                    mnuLarge.Checked = false;
                    lvwFiles.View = View.SmallIcon;
                    break;
                case "큰 아이콘":
                    mnuLarge.Checked = true;
                    mnuSmall.Checked = false;
                    lvwFiles.View = View.LargeIcon;
                    break;

            }
            */
        }


        public void setPlus(TreeNode node)
        {
            string path;
            DirectoryInfo dir;
            DirectoryInfo[] di;

            try
            {
                path = node.FullPath;
                dir = new DirectoryInfo(path);
                di = dir.GetDirectories();
                if (di.Length > 0)
                    node.Nodes.Add("");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void OpenItem(ListViewItem item)
        {
            TreeNode node;
            TreeNode child;
            if (item.Tag.ToString() == "D")
            {
                node = trvDir.SelectedNode;
                node.Expand();

                child = node.FirstNode;
                while (child != null)
                {
                    if (child.Text == item.Text)
                    {
                        trvDir.SelectedNode = child;
                        trvDir.Focus();
                        break;
                    }
                    child = child.NextNode;
                }
            }
            else
            {
                imformation_window();
            }
        }

        private void trvDir_BeforeSelect(object sender, TreeViewCancelEventArgs e)
        {
            AddTextDelegate AddText = new AddTextDelegate(history.AppendText);
            Invoke(AddText, "BeforeSelect() ");
            Invoke(AddText, "\r\n");

            //   history.AppendText("BeforeSelect() ");
            /*    Thread Select_Send;
                Select_Send = new Thread(new ThreadStart(Send));
                Thread Receive_Send;
                Receive_Send = new Thread(new ThreadStart(Receive));
                */
            DirectoryInfo di;
            DirectoryInfo[] diarray;
            ListViewItem item;
            FileInfo[] fiArray;

            try
            {
                PMessage Me = new PMessage();
                Me.command = "demand BeforeSelect";
                Me.SelectedNode = e.Node.FullPath;
                stream.Flush();
                Packet.Serialize(Me).CopyTo(sendBuffer, 0);
                        
                if (Send())
                    Receive();

                stream.Flush();
                di = message_Class.di;
                Invoke(AddText, "this is BeforeSelect di:");
                Invoke(AddText, di.ToString());
                Invoke(AddText, "\r\n");
                lvwFiles.Items.Clear();

                diarray = message_Class.diarray;
                Invoke(AddText, "this is BeforeSelect diarray:");
                Invoke(AddText, diarray.ToString());
                Invoke(AddText, "\r\n");
                foreach (DirectoryInfo tdis in diarray)
                {
                    item = lvwFiles.Items.Add(tdis.Name);
                    item.SubItems.Add("");
                    item.SubItems.Add(tdis.LastWriteTime.ToString());
                    item.ImageIndex = 0;
                    item.Tag = "D";
                }
                fiArray = message_Class.fiArray;
                foreach (FileInfo fis in fiArray)
                {
                    item = lvwFiles.Items.Add(fis.Name);
                    item.SubItems.Add(fis.Length.ToString());
                    item.SubItems.Add(fis.LastWriteTime.ToString());
                    item.ImageIndex = 1;
                    item.Tag = "F";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
      
        private void Select_folder(string e_path)
        {
            AddTextDelegate AddText = new AddTextDelegate(history.AppendText);
            Invoke(AddText, "Select()_folder ");
            Invoke(AddText, "\r\n");

         
            DirectoryInfo di;
            DirectoryInfo[] diarray;
            ListViewItem item;
            FileInfo[] fiArray;
           
            try
            {
                PMessage Me = new PMessage();
                Me.command = "demand Selectfolder";
                Me.SelectedNode = e_path;
                stream.Flush();
                Packet.Serialize(Me).CopyTo(sendBuffer, 0);
                if (Send())
                    Receive();

                stream.Flush();
                di = message_Class.di;
                Invoke(AddText, "this is Select di:");
                Invoke(AddText, di.ToString());
                Invoke(AddText, "\r\n");
                lvwFiles.Items.Clear();

                diarray = message_Class.diarray;
                Invoke(AddText, "this is Select diarray:");
                Invoke(AddText, diarray.ToString());
                Invoke(AddText, "\r\n");
                foreach (DirectoryInfo tdis in diarray)
                {
                    item = lvwFiles.Items.Add(tdis.Name);
                    item.SubItems.Add("");
                    item.SubItems.Add(tdis.LastWriteTime.ToString());
                    item.ImageIndex = 0;
                    item.Tag = "D";
                }
                fiArray = message_Class.fiArray;
                foreach (FileInfo fis in fiArray)
                {
                    item = lvwFiles.Items.Add(fis.Name);
                    item.SubItems.Add(fis.Length.ToString());
                    item.SubItems.Add(fis.LastWriteTime.ToString());
                    item.ImageIndex = 1;
                    item.Tag = "F";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            TreeNode root = new TreeNode(e_path);
            root = trvDir.Nodes.Add(e_path);
         //   root.ImageIndex = 2;
            trvDir.SelectedNode = root;
          //  root.SelectedImageIndex = root.ImageIndex;
          //  root.Nodes.Add("");

        }
        private void PORT_TEXT_TextChanged(object sender, EventArgs e)
        {

        }

        private void trvDir_BeforeLabelEdit(object sender, NodeLabelEditEventArgs e)
        {

        }

        private void trvDir_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            AddTextDelegate AddText = new AddTextDelegate(history.AppendText);
            Invoke(AddText, "BeforeExpand() ");
            Invoke(AddText, "\r\n");

            //   history.AppendText("BeforeExpand() ");
            PMessage Me = new PMessage();
            Me.command = "demand BeforeExpand";
            Me.SelectedNode = e.Node.FullPath;
            stream.Flush();
            Packet.Serialize(Me).CopyTo(sendBuffer, 0);
            if (Send())
                Receive();
            stream.Flush();
            DirectoryInfo dir = message_Class.di;
            DirectoryInfo[] di = message_Class.diarray;
            Invoke(AddText, "this is BeforeExpand diarray:");
            Invoke(AddText, di.ToString());
            Invoke(AddText, "\r\n");
            TreeNode node;

            try
            {
                e.Node.Nodes.Clear();
                foreach (DirectoryInfo dirs in di)
                {
                    node = e.Node.Nodes.Add(dirs.Name);
                    setPlus(node);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mnuImformation_Click(object sender, EventArgs e)
        {
            if (lvwFiles.SelectedItems[0].Tag == "D")
                MessageBox.Show("디렉토리는 불가능합니다.", "ERROR");
            else
                imformation_window();
        }
        private void imformation_window()
            { 
                AddTextDelegate AddText = new AddTextDelegate(history.AppendText);
                Invoke(AddText, "demand imformation");
                Invoke(AddText, "\r\n");
                Form3 Imformation = new Form3();
                PMessage Me = new PMessage();

                Me.command = "demand imformation";
                Me.PATH = trvDir.SelectedNode.FullPath + "\\" + lvwFiles.SelectedItems[0].Text;
                stream.Flush();
                Packet.Serialize(Me).CopyTo(sendBuffer, 0);
                if (Send())
                   infoReceive();                                  
                      Imformation.pictureBox1.Image = imageList1.Images[0];
                      switch (info_Class.Extenstion)
                      {
                          case ".mp3":
                              Imformation.pictureBox1.Image = imageList1.Images[3]; break;
                          case ".avi":
                              Imformation.pictureBox1.Image = imageList1.Images[0]; break;
                          case ".txt":
                              Imformation.pictureBox1.Image = imageList1.Images[5]; break;
                          case ".png":
                              Imformation.pictureBox1.Image = imageList1.Images[2]; break;
                          case ".jpg":
                              Imformation.pictureBox1.Image = imageList1.Images[2]; break;
                          default:
                              Imformation.pictureBox1.Image = imageList1.Images[4]; break;
                      }
                      Imformation.textBox1.AppendText(lvwFiles.SelectedItems[0].Text);
                      Imformation.label1.Text += "" + info_Class.Extenstion;
                      Imformation.label2.Text += "" + info_Class.DirectoryName;
                      Imformation.label3.Text += "" + info_Class.Len + "  bytes";
                      Imformation.label4.Text += "" +info_Class.CreationTime;
                      Imformation.label5.Text += "" + info_Class.LastWriteTime;
                      Imformation.label6.Text += "" + info_Class.LastAccessTime;
                      
                    Imformation.Show();
            }

        
       

        private void mnuDownload_Click(object sender, EventArgs e)
        {
            if (lvwFiles.SelectedItems[0].Tag == "D")
                MessageBox.Show("디렉토리 대상으로는 수행 불가능합니다.", "ERROR");
            else
            {
                AddTextDelegate AddText = new AddTextDelegate(history.AppendText);
                Invoke(AddText, "demand Download");
                Invoke(AddText, "\r\n");
                //   history.AppendText("BeforeExpand() ");
                PMessage Me = new PMessage();

                Me.command = "demand Download";
                Me.PATH = trvDir.SelectedNode.FullPath + "\\" + lvwFiles.SelectedItems[0].Text;
                stream.Flush();
                Packet.Serialize(Me).CopyTo(sendBuffer, 0);
                if (Send())
                 fileReceive();
                stream.Flush();
                FileStream fs = new FileStream(PATH_TEXT.Text + "\\" + download_Class.Filename, FileMode.Create);
                fs.Write(download_Class.buf, 0, download_Class.filelength);
                fs.Close();
                Me.command = "complete_Download";
                Packet.Serialize(Me).CopyTo(sendBuffer, 0);
                Send();                
                stream.Flush();
            }
        }

        private void mnuDetail_Click(object sender, EventArgs e)
        {
            mnuDetail.Checked = true;
            mnuSimple.Checked = false;
            lvwFiles.View = View.Details;
        }

      

        private void mnuSmall_Click(object sender, EventArgs e)
        {
            mnuSmall.Checked = true;
            mnuLarge.Checked = false;
            lvwFiles.View = View.SmallIcon;
        }

        private void mnuLarge_Click(object sender, EventArgs e)
        {

            mnuLarge.Checked = true;
            mnuSmall.Checked = false;
            lvwFiles.View = View.LargeIcon;
        }

        private void folderOpen_Click(object sender, EventArgs e)
        {
            if (PATH_TEXT.Text != "")
                Process.Start(PATH_TEXT.Text);
        }

        private void mnuSimple_Click(object sender, EventArgs e)
        {
            mnuDetail.Checked = false;
            mnuSimple.Checked = true;
            lvwFiles.View = View.List;
        }
        
        private void lvwFiles_DoubleClick(object sender, EventArgs e)
        {
            /*
             * if (lvwFiles.SelectedItems[0].Tag == "D")
             {

                 string SelectedItem = lvwFiles.SelectedItems[0].Text;
                 string A = trvDir.SelectedNode.FullPath;
                 A += "\\";
                 string last=A+SelectedItem;         
                 Select_folder(last);
             }
             */
            OpenFiles();
        }
    }
}


