﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;
namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public NetworkStream m_Stream;
        public StreamReader m_Read;
        public StreamWriter m_Write;
        public int PORT;
     //   private Thread m_ThReader;
        public bool m_bStop = false;
        private TcpListener m_listener;
        private Thread m_thServer;
        public bool m_bConnect = false;
        

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void path_button_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.RootFolder = Environment.SpecialFolder.Desktop;
            fbd.Description = "Select Folder";
            fbd.ShowNewFolderButton = false;

            if(fbd.ShowDialog()==DialogResult.OK)
            {
                PATH_TEXT.Text = fbd.SelectedPath;
                txt_all.Text = fbd.SelectedPath;
                txt_all.Text += "로 경로가 변경되었습니다.\n";
            }
        }
        public void Message(string msg)
        {
            txt_all.AppendText(msg + "\r\n");
            txt_all.Focus();
            txt_all.ScrollToCaret();
        }
        public void ServerStart()
        {
            try
            {
               
                var port = int.Parse(PORT_TEXT.Text);              
                IPAddress localAddr = IPAddress.Parse(IP_TEXT.Text);
                try
                {
                    m_listener = new TcpListener(localAddr,port);
                    m_listener.Start();
                    m_bStop = true;               

                }
                catch (SocketException e)
                {
                    txt_all.Text = "IP or PORT error";
                    m_listener.Stop();
                }
                txt_all.Text += "클라이언트 접속 대기중....";

          //      while (m_bStop)
            //        {
                //    txt_all.Text += "클라이언트 접속 대기중....";
                    TcpClient hClient = m_listener.AcceptTcpClient();
              //      DateTime t = DateTime.Now;

                     //   if (hClient.Connected)
            //            {
                            m_bConnect = true;
                            txt_all.Text += "클라이언트 접속";

                      //      m_Stream = hClient.GetStream();
/*
                        }
                        
                    }*/
               
            }
            catch (SocketException e)
            {
                txt_all.Text += "시작 도중에 오류 발생";
                return;
            }
        }
        public void ServerStop()
        {
            if (!m_bStop)
                return;
            m_listener.Stop();
            //m_Read.Close();
           // m_Write.Close();

          //  m_Stream.Close();

      //      m_ThReader.Abort();
       //     m_thServer.Abort();

            txt_all.Text="서비스 종료";
        }
        public void Disconnect()
        {
            if (!m_bConnect)
                return;
            m_bConnect = false;

            m_Read.Close();
            m_Write.Close();

            m_Stream.Close();
        //    m_ThReader.Abort();
            txt_all.Text = "상대방과 연결중단";


        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void PATH_TEXT_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            ServerStop();
            Disconnect();
        }

        private void server_button_Click(object sender, EventArgs e)
        {
            if (PATH_TEXT.Text == "")
            {
                 MessageBox.Show("경로를 입력해주세요.");
            }

            else
            {   
                if (server_button.Text == "서버켜기")
                {
                    //   m_thServer = new Thread(new ThreadStart(ServerStart));
                    //   m_thServer.Start();
                  
                    ServerStart();
                    server_button.Text = "서버멈춤";
                    server_button.ForeColor = Color.Red;
                }
                else
                {
                    ServerStop();
                    server_button.Text = "서버켜기";
                    server_button.ForeColor = Color.Black;
                }
            }
        }
            }
        }
        
    
