﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
namespace packet_libirary
{
        public enum PacketType
        {
            초기화 = 0,
            로그인
        }

        public enum PacketSendERROR
        {
            정상 = 0,
            에러
        }

        [Serializable]
        public class Packet
        {
            public int Length;
            public int Type;
        
           
        public Packet()
            {  
                this.Length = 0;
                this.Type = 0;            
            }
            public static byte[] FileSerialize(Object o)
            {
            MemoryStream ms = new MemoryStream(1024*4*3000);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ms, o);
            return ms.ToArray();
            }
            public static byte[] Serialize(Object o)
            {
                MemoryStream ms = new MemoryStream(1024 * 4);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(ms, o);
                return ms.ToArray();
            }
            public static Object FileDesserialize(byte[] bt)
             {
                MemoryStream ms = new MemoryStream(1024 * 4*3000);
                foreach (byte b in bt)
                {
                    ms.WriteByte(b);
                }

                ms.Position = 0;
                BinaryFormatter bf = new BinaryFormatter();
                ms.Seek(0, SeekOrigin.Begin);
                object obj = bf.Deserialize(ms);       
                ms.Close();
                return obj;
            }
        public static Object Desserialize(byte[] bt)
            {
                MemoryStream ms = new MemoryStream(1024 * 4);
                foreach (byte b in bt)
                {
                    ms.WriteByte(b);
                }

                ms.Position = 0;
                BinaryFormatter bf = new BinaryFormatter();
                object obj = bf.Deserialize(ms);
                ms.Close();
                return obj;
            }
        }

        [Serializable]
        public class Initialize : Packet
    {
        public int Data = 0;
        public DirectoryInfo[] diarray;
        public FileInfo[] fiArray;
        public string PATH;
    }
    [Serializable]
    public class fileimformation: Packet
    {
            public string Extenstion;
            public string DirectoryName;
            public string Len;
            public string CreationTime;
            public string LastWriteTime;
            public string LastAccessTime;       
    }
    [Serializable]
    public class PMessage : Packet
    {
        public int Data = 0;
        public string command;
        public string message;
        public DirectoryInfo di;
        public DirectoryInfo[] diarray;
        public FileInfo[] fiArray;
        public string PATH;
        public string SelectedNode;
    }

    [Serializable]
    public class PDownload : Packet
    {
        public string Filename;
        public int filelength;
        public byte[] buf;
    }
    [Serializable]
        public class Login : Packet
        {
            public string m_strID;

            public Login()
            {
                this.m_strID = null;
            }
        }
    }
